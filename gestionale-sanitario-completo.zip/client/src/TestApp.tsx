import React from 'react';

function TestApp() {
  return (
    <div>
      <h1>Applicazione di Test</h1>
      <p>Se vedi questo messaggio, React sta funzionando correttamente.</p>
    </div>
  );
}

export default TestApp;