// @ts-nocheck
import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  BarChart as BarChartIcon, 
  PieChart as PieChartIcon, 
  LineChart as LineChartIcon,
  Download,
  Calendar,
  UserCheck,
  Clock,
  Loader2,
  Crown,
  CalendarPlus,
  FileSpreadsheet,
  Receipt
} from "lucide-react";
import { useTranslation } from 'react-i18next';
import { Link } from 'wouter';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, getDay, startOfWeek, endOfWeek, addMonths, subMonths } from "date-fns";
import { getDateLocale } from '@/lib/utils/date';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  Cell,
  PieChart,
  Pie
} from "recharts";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { formatDateForApi } from "@/lib/utils/date";
import ProFeatureGuard from "@/components/ProFeatureGuard";
import ProFeatureNavbar from "@/components/ProFeatureNavbar";
import { buildPeriodBuckets, aggregateAppointments, calculateRevenue } from "@/lib/reports";
import { useCurrency } from "@/hooks/use-currency";

export default function Reports() {
  const { t, i18n } = useTranslation();
  
  return (
    <ProFeatureGuard 
      featureName={t('reports.title')}
      description={t('proFeature.reportsDescription')}
      requiredCapability="reports"
    >
      <ReportsContent />
    </ProFeatureGuard>
  );
}

function ReportsContent() {
  const { t, i18n } = useTranslation();
  const { symbol } = useCurrency();
  const [reportType, setReportType] = useState("monthly");
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [aggregatedData, setAggregatedData] = useState<any[]>([]);
  const [serviceData, setServiceData] = useState<any[]>([]);
  
  // Create date range based on selected report type
  const getDateRange = () => {
    if (reportType === "weekly") {
      return {
        start: formatDateForApi(startOfWeek(selectedDate, { locale: getDateLocale(i18n.language) })),
        end: formatDateForApi(endOfWeek(selectedDate, { locale: getDateLocale(i18n.language) }))
      };
    } else if (reportType === "monthly") {
      return {
        start: formatDateForApi(startOfMonth(selectedDate)),
        end: formatDateForApi(endOfMonth(selectedDate))
      };
    } else {
      // For yearly, we use Jan 1 to Dec 31
      return {
        start: `${selectedDate.getFullYear()}-01-01`,
        end: `${selectedDate.getFullYear()}-12-31`
      };
    }
  };
  
  const { start, end } = getDateRange();
  
  // Fetch appointments for the selected date range
  const { data: appointments = [], isLoading: isLoadingAppointments } = useQuery<any>({
    queryKey: [`/api/appointments/range/${start}/${end}`],
  });
  
  // Fetch all services
  const { data: services = [], isLoading: isLoadingServices } = useQuery<any>({
    queryKey: ['/api/services'],
  });
  
  // Note: calculateRevenue function is now imported from @/lib/reports

  // 📊 AGGREGAZIONE DATI UNIFICATA - Usa logica condivisa per tutti i tipi di report
  useEffect(() => {
    if (appointments.length === 0 || isLoadingAppointments || isLoadingServices) return;
    
    // 🗓️ Genera buckets di tempo per il tipo di report selezionato
    const buckets = buildPeriodBuckets(reportType, selectedDate, i18n.language);
    
    // 📈 Aggrega dati usando la logica condivisa (stessa che funziona per annuale)
    const aggregatedReportData = aggregateAppointments(buckets, appointments, services);
    
    setAggregatedData(aggregatedReportData);
    
    // 🎯 Aggregazione per tipo di servizio (usa la stessa logica di calcolo revenue)
    const serviceAggregation = services.map(service => {
      const serviceAppointments = appointments.filter(a => a.serviceId === service.id);
      
      return {
        name: service.name,
        count: serviceAppointments.length,
        revenue: calculateRevenue(serviceAppointments, services),
        color: service.color || "#3f51b5"
      };
    }).filter(s => s.count > 0);
    
    setServiceData(serviceAggregation);
    
  }, [appointments, services, reportType, selectedDate, isLoadingAppointments, isLoadingServices]);
  
  // Navigation functions
  const goToPrevious = () => {
    if (reportType === "weekly") {
      setSelectedDate(prevDate => {
        const newDate = new Date(prevDate);
        newDate.setDate(newDate.getDate() - 7);
        return newDate;
      });
    } else if (reportType === "monthly") {
      setSelectedDate(prevDate => subMonths(prevDate, 1));
    } else {
      setSelectedDate(prevDate => {
        const newDate = new Date(prevDate);
        newDate.setFullYear(newDate.getFullYear() - 1);
        return newDate;
      });
    }
  };
  
  const goToNext = () => {
    if (reportType === "weekly") {
      setSelectedDate(prevDate => {
        const newDate = new Date(prevDate);
        newDate.setDate(newDate.getDate() + 7);
        return newDate;
      });
    } else if (reportType === "monthly") {
      setSelectedDate(prevDate => addMonths(prevDate, 1));
    } else {
      setSelectedDate(prevDate => {
        const newDate = new Date(prevDate);
        newDate.setFullYear(newDate.getFullYear() + 1);
        return newDate;
      });
    }
  };
  
  const goToCurrent = () => {
    setSelectedDate(new Date());
  };
  
  // Title based on report type
  const getReportTitle = () => {
    if (reportType === "weekly") {
      const weekStart = startOfWeek(selectedDate, { locale: getDateLocale(i18n.language) });
      const weekEnd = endOfWeek(selectedDate, { locale: getDateLocale(i18n.language) });
      return `${t('reports.week')} ${format(weekStart, 'd MMM', { locale: getDateLocale(i18n.language) })} - ${format(weekEnd, 'd MMM yyyy', { locale: getDateLocale(i18n.language) })}`;
    } else if (reportType === "monthly") {
      return format(selectedDate, 'MMMM yyyy', { locale: getDateLocale(i18n.language) });
    } else {
      return `${t('reports.year')} ${selectedDate.getFullYear()}`;
    }
  };
  
  // Calculate summary statistics
  const totalAppointments = aggregatedData.reduce((sum, day) => sum + day.count, 0);
  const totalRevenue = aggregatedData.reduce((sum, day) => sum + day.revenue, 0);
  const avgAppointmentsPerDay = totalAppointments / Math.max(aggregatedData.length, 1);
  
  // Get different colors for services
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#FF6B6B', '#6B66FF'];
  
  // Generate PDF report
  const generatePdfReport = () => {
    const reportTitle = getReportTitle();
    const periodColumnHeader = reportType === "weekly" ? t('reports.day') : reportType === "monthly" ? t('reports.date') : t('reports.month');
    const dateLocale = i18n.language === 'it' ? 'it-IT' : i18n.language === 'de' ? 'de-DE' : i18n.language === 'es' ? 'es-ES' : i18n.language === 'fr' ? 'fr-FR' : i18n.language === 'nl' ? 'nl-NL' : i18n.language === 'no' ? 'nb-NO' : i18n.language === 'ro' ? 'ro-RO' : i18n.language === 'ru' ? 'ru-RU' : 'en-US';
    
    // Create printable version for download
    const printContent = `
      <html>
        <head>
          <title>Report - ${reportTitle}</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 40px; }
            h1 { font-size: 24px; margin-bottom: 20px; text-align: center; }
            h2 { font-size: 18px; margin-top: 30px; margin-bottom: 10px; }
            .summary { margin-bottom: 20px; display: flex; justify-content: space-between; }
            .summary-item { padding: 15px; border: 1px solid #e0e0e0; border-radius: 5px; width: 30%; text-align: center; }
            .summary-item h3 { margin-top: 0; margin-bottom: 10px; font-size: 16px; color: #666; }
            .summary-item p { margin: 0; font-size: 24px; font-weight: bold; }
            .data-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            .data-table th, .data-table td { padding: 8px; text-align: left; border-bottom: 1px solid #e0e0e0; }
            .data-table th { background-color: #f5f5f5; font-weight: bold; }
            .date { margin-top: 30px; text-align: right; font-size: 12px; color: #666; }
          </style>
        </head>
        <body>
          <h1>Report - ${reportTitle}</h1>
          
          <div class="summary">
            <div class="summary-item">
              <h3>${t('reports.totalAppointments')}</h3>
              <p>${totalAppointments}</p>
            </div>
            <div class="summary-item">
              <h3>${t('reports.totalRevenue')}</h3>
              <p>${symbol}${totalRevenue.toFixed(2)}</p>
            </div>
            <div class="summary-item">
              <h3>${t('reports.dailyAverage')}</h3>
              <p>${avgAppointmentsPerDay.toFixed(1)}</p>
            </div>
          </div>
          
          <h2>${t('reports.appointmentDetails')}</h2>
          <table class="data-table">
            <tr>
              <th>${periodColumnHeader}</th>
              <th>${t('reports.numberOfAppointments')}</th>
              <th>${t('reports.revenue')}</th>
            </tr>
            ${aggregatedData.map(data => `
              <tr>
                <td>${data.name}</td>
                <td>${data.count}</td>
                <td>${symbol}${data.revenue.toFixed(2)}</td>
              </tr>
            `).join('')}
          </table>
          
          <h2>${t('reports.serviceDetails')}</h2>
          <table class="data-table">
            <tr>
              <th>${t('reports.service')}</th>
              <th>${t('reports.numberOfAppointments')}</th>
              <th>${t('reports.revenue')}</th>
            </tr>
            ${serviceData.map(service => `
              <tr>
                <td>${service.name}</td>
                <td>${service.count}</td>
                <td>${symbol}${service.revenue.toFixed(2)}</td>
              </tr>
            `).join('')}
          </table>
          
          <div class="date">
            ${t('reports.generatedOn')}: ${new Date().toLocaleDateString(dateLocale)} ${t('reports.at')} ${new Date().toLocaleTimeString(dateLocale)}
          </div>
        </body>
      </html>
    `;
    
    // Open printable version in a new window
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.focus();
      
      // Print or save as PDF
      setTimeout(() => {
        printWindow.print();
      }, 500);
    }
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center space-y-4 md:space-y-0">
        <h2 className="text-2xl font-medium">{t('reports.title')}</h2>
        
        <Button variant="outline" onClick={generatePdfReport}>
          <Download className="mr-2 h-4 w-4" />
          {t('reports.exportPdf')}
        </Button>
      </div>
      
      {/* Report Type Selector and Navigation */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center space-y-4 md:space-y-0">
        <Tabs defaultValue="monthly" value={reportType} onValueChange={setReportType}>
          <TabsList>
            <TabsTrigger value="weekly">
              <Calendar className="h-4 w-4 mr-2" />
              {t('reports.weekly')}
            </TabsTrigger>
            <TabsTrigger value="monthly">
              <Calendar className="h-4 w-4 mr-2" />
              {t('reports.monthly')}
            </TabsTrigger>
            <TabsTrigger value="yearly">
              <Calendar className="h-4 w-4 mr-2" />
              {t('reports.yearly')}
            </TabsTrigger>
          </TabsList>
        </Tabs>
        
        <div className="flex items-center space-x-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={goToPrevious}
          >
            {t('reports.previous')}
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={goToCurrent}
          >
            {t('reports.current')}
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={goToNext}
          >
            {t('reports.next')}
          </Button>
        </div>
      </div>
      
      {/* Report Title */}
      <div className="text-center my-6">
        <h3 className="text-2xl font-bold">{getReportTitle()}</h3>
      </div>
      
      {/* Loading State */}
      {(isLoadingAppointments || isLoadingServices) && (
        <div className="flex justify-center p-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      )}
      
      {/* Summary Cards */}
      {!isLoadingAppointments && !isLoadingServices && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  {t('reports.totalAppointments')}
                </CardTitle>
                <UserCheck className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{totalAppointments}</div>
                <p className="text-xs text-muted-foreground">
                  {appointments.length === 0 
                    ? t('reports.noAppointmentsInPeriod') 
                    : `+${Math.round(totalAppointments / aggregatedData.length)} ${t('reports.perDay')}`}
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  {t('reports.estimatedRevenue')}
                </CardTitle>
                <BarChartIcon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{symbol}{totalRevenue.toFixed(2)}</div>
                <p className="text-xs text-muted-foreground">
                  {appointments.length === 0 
                    ? t('reports.noAppointmentsInPeriod') 
                    : `${symbol}${(totalRevenue / aggregatedData.length).toFixed(2)} ${t('reports.perDay')}`}
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  {t('reports.dailyAverage')}
                </CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{avgAppointmentsPerDay.toFixed(1)}</div>
                <p className="text-xs text-muted-foreground">
                  {t('reports.appointmentsPerDay')}
                </p>
              </CardContent>
            </Card>
          </div>
          
          {/* Charts */}
          {appointments.length > 0 ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Appointments by Time Period */}
              <Card className="col-span-1">
                <CardHeader>
                  <CardTitle>{t('reports.appointmentsBy')} {reportType === "weekly" ? t('reports.day') : reportType === "monthly" ? t('reports.date') : t('reports.month')}</CardTitle>
                </CardHeader>
                <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={aggregatedData}
                      margin={{
                        top: 20,
                        right: 30,
                        left: 20,
                        bottom: 5,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip 
                        formatter={(value, name) => {
                          if (name === "count") return [value, t('reports.appointments')];
                          if (name === "revenue") return [`${symbol}${value}`, t('reports.revenue')];
                          return [value, name];
                        }}
                      />
                      <Legend />
                      <Bar dataKey="count" name={t('reports.appointments')} fill="#8884d8" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
              
              {/* Services Breakdown */}
              <Card className="col-span-1">
                <CardHeader>
                  <CardTitle>{t('reports.serviceDistribution')}</CardTitle>
                </CardHeader>
                <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={serviceData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        dataKey="count"
                      >
                        {serviceData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color || COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip
                        formatter={(value, name, props) => [`${value} ${t('reports.appointments').toLowerCase()}`, props.payload.name]}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
              
              {/* Revenue Chart */}
              <Card className="col-span-1 lg:col-span-2">
                <CardHeader>
                  <CardTitle>{t('reports.revenueBy')} {reportType === "weekly" ? t('reports.day') : reportType === "monthly" ? t('reports.date') : t('reports.month')}</CardTitle>
                </CardHeader>
                <CardContent className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={aggregatedData}
                      margin={{
                        top: 20,
                        right: 30,
                        left: 20,
                        bottom: 5,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip 
                        formatter={(value) => [`${symbol}${value}`, t('reports.revenue')]}
                      />
                      <Legend />
                      <Bar dataKey="revenue" name={t('reports.revenue')} fill="#82ca9d" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-md p-8 text-center">
              <BarChartIcon className="mx-auto h-12 w-12 text-gray-400 mb-3" />
              <h3 className="text-lg font-medium text-gray-900 mb-1">{t('reports.noDataForPeriod')}</h3>
              <p className="text-gray-500 mb-4">
                {t('reports.noAppointmentsRegistered')}
              </p>
            </div>
          )}
        </>
      )}
    </div>
  );
}
