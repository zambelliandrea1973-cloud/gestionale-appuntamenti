declare module 'qrcode-terminal' {
  export function generate(text: string, options?: any): void;
  export function setErrorLevel(level: string): void;
}