import express from 'express';
import { storage } from '../storage';
import { isPaymentAdmin } from '../middleware/paymentAdminAuth';
import { isAdminOrStaff } from '../middleware/authMiddleware';
import Stripe from 'stripe';
import paypal from '@paypal/checkout-server-sdk';

// Creazione del router Express
const router = express.Router();

// Configurazione del client Stripe (se le credenziali esistono)
const setupStripeClient = (secretKey: string) => {
  return new Stripe(secretKey, {
    apiVersion: '2023-10-16',
  });
};

// Configurazione del client PayPal (se le credenziali esistono)
const setupPaypalClient = (clientId: string, clientSecret: string, mode: 'sandbox' | 'live') => {
  const environment = mode === 'live'
    ? new paypal.core.LiveEnvironment(clientId, clientSecret)
    : new paypal.core.SandboxEnvironment(clientId, clientSecret);
  
  return new paypal.core.PayPalHttpClient(environment);
};

/**
 * Ottiene i metodi di pagamento configurati
 * GET /api/payments/payment-admin/payment-methods
 * Accesso: payment admin
 */
router.get('/payment-admin/payment-methods', isPaymentAdmin, async (req, res) => {
  try {
    let paymentMethods = await storage.getPaymentMethods();
    const isProduction = process.env.PAYMENT_MODE === 'production';
    
    if (!paymentMethods || paymentMethods.length === 0) {
      // Se non ci sono metodi configurati, crea configurazione iniziale con Stripe e PayPal
      const defaultMethods = [
        {
          id: 'stripe',
          name: 'Carta di Credito (Stripe)',
          enabled: true,
          config: {
            publicKey: isProduction 
              ? (process.env.VITE_STRIPE_PUBLIC_KEY_LIVE || '') 
              : (process.env.VITE_STRIPE_PUBLIC_KEY || ''),
            secretKey: isProduction 
              ? (process.env.STRIPE_SECRET_KEY_LIVE || '') 
              : (process.env.STRIPE_SECRET_KEY || ''),
            webhookSecret: '',
            statementDescriptor: 'Gestionale Appuntamenti'
          }
        },
        {
          id: 'paypal',
          name: 'PayPal',
          enabled: true,
          config: {
            clientId: isProduction 
              ? (process.env.PAYPAL_CLIENT_ID_LIVE || '') 
              : (process.env.PAYPAL_CLIENT_ID || ''),
            clientSecret: isProduction 
              ? (process.env.PAYPAL_CLIENT_SECRET_LIVE || '') 
              : (process.env.PAYPAL_CLIENT_SECRET || ''),
            mode: isProduction ? 'live' : 'sandbox'
          }
        },
        {
          id: 'wise',
          name: 'Wise (TransferWise)',
          enabled: false,
          config: {
            apiKey: '',
            profileId: '',
            accountId: '',
            recipientEmail: ''
          }
        },
        {
          id: 'bank',
          name: 'Bonifico Bancario',
          enabled: false,
          config: {
            accountName: '',
            iban: '',
            swift: '',
            bankName: '',
            instructions: ''
          }
        }
      ];
      
      // Salva la configurazione iniziale
      await storage.savePaymentMethods(defaultMethods);
      paymentMethods = defaultMethods;
      
      console.log('✅ Configurazione metodi di pagamento inizializzata automaticamente');
    } else {
      // Popola automaticamente i campi vuoti con valori degli environment secrets
      paymentMethods = paymentMethods.map(method => {
        if (method.id === 'stripe' && method.config) {
          // Se i campi Stripe sono vuoti, usa gli environment secrets
          if (!method.config.publicKey || !method.config.secretKey) {
            method.config.publicKey = isProduction 
              ? (process.env.VITE_STRIPE_PUBLIC_KEY_LIVE || '') 
              : (process.env.VITE_STRIPE_PUBLIC_KEY || '');
            method.config.secretKey = isProduction 
              ? (process.env.STRIPE_SECRET_KEY_LIVE || '') 
              : (process.env.STRIPE_SECRET_KEY || '');
            console.log('✅ Chiavi Stripe popolate dagli environment secrets');
          }
        }
        return method;
      });
    }
    
    // Restituisci le credenziali complete (utente autenticato come payment admin)
    return res.json(paymentMethods);
  } catch (error) {
    console.error('Errore durante il recupero dei metodi di pagamento:', error);
    return res.status(500).json({
      success: false,
      message: 'Errore interno del server: ' + (error instanceof Error ? error.message : String(error))
    });
  }
});

/**
 * Salva configurazione dei metodi di pagamento
 * POST /api/payments/payment-admin/payment-methods
 * Accesso: payment admin
 */
router.post('/payment-admin/payment-methods', isPaymentAdmin, async (req, res) => {
  try {
    const { paymentMethods } = req.body;
    
    if (!paymentMethods || !Array.isArray(paymentMethods)) {
      return res.status(400).json({
        success: false,
        message: 'Dati dei metodi di pagamento non validi'
      });
    }
    
    // Salva i metodi di pagamento così come arrivano (credenziali complete)
    await storage.savePaymentMethods(paymentMethods);
    
    return res.json({
      success: true,
      message: 'Configurazione dei metodi di pagamento salvata con successo'
    });
  } catch (error) {
    console.error('Errore durante il salvataggio dei metodi di pagamento:', error);
    return res.status(500).json({
      success: false,
      message: 'Errore interno del server: ' + (error instanceof Error ? error.message : String(error))
    });
  }
});

/**
 * Testa la configurazione di un metodo di pagamento
 * POST /api/payments/payment-admin/test-payment-method/:id
 * Accesso: payment admin
 */
router.post('/payment-admin/test-payment-method/:id', isPaymentAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const { config } = req.body;
    
    if (!config) {
      return res.status(400).json({
        success: false,
        message: 'Configurazione metodo di pagamento mancante'
      });
    }
    
    // Testa la configurazione in base al tipo di metodo
    if (id === 'stripe') {
      if (!config.secretKey) {
        return res.status(400).json({
          success: false,
          message: 'Chiave segreta Stripe mancante'
        });
      }
      
      try {
        const stripe = setupStripeClient(config.secretKey);
        // Verifica la validità della chiave ottenendo il bilancio dell'account
        const balance = await stripe.balance.retrieve();
        
        return res.json({
          success: true,
          message: 'Configurazione Stripe valida'
        });
      } catch (stripeError: any) {
        return res.status(400).json({
          success: false,
          message: `Errore configurazione Stripe: ${stripeError.message}`
        });
      }
    } 
    else if (id === 'paypal') {
      if (!config.clientId || !config.clientSecret) {
        return res.status(400).json({
          success: false,
          message: 'Credenziali PayPal mancanti'
        });
      }
      
      try {
        console.log('🔧 PayPal test - Setup client con mode:', config.mode || 'sandbox');
        const paypalClient = setupPaypalClient(config.clientId, config.clientSecret, config.mode || 'sandbox');
        
        // Verifica le credenziali creando un ordine di prova con il vecchio SDK
        const request = new paypal.orders.OrdersCreateRequest();
        request.prefer("return=representation");
        request.requestBody({
          intent: 'CAPTURE',
          purchase_units: [{
            amount: {
              currency_code: 'EUR',
              value: '1.00'
            }
          }]
        });
        
        const response = await paypalClient.execute(request);
        
        // Se arriviamo qui, le credenziali sono valide
        console.log('✅ PayPal test OK - Order ID:', response.result.id);
        return res.json({
          success: true,
          message: 'Configurazione PayPal valida',
          testOrderId: response.result.id
        });
      } catch (paypalError: any) {
        console.error('❌ PayPal test ERRORE:', paypalError);
        console.error('❌ PayPal error stack:', paypalError.stack);
        console.error('❌ PayPal error message:', paypalError.message);
        return res.status(400).json({
          success: false,
          message: `Errore configurazione PayPal: ${paypalError.message || 'Credenziali non valide'}`
        });
      }
    } 
    else if (id === 'wise') {
      if (!config.apiKey) {
        return res.status(400).json({
          success: false,
          message: 'API Key Wise mancante'
        });
      }
      
      try {
        // Per Wise, facciamo una semplice richiesta di prova all'API
        const response = await fetch('https://api.transferwise.com/v3/profiles', {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${config.apiKey}`,
            'Content-Type': 'application/json'
          }
        });
        
        if (!response.ok) {
          throw new Error(`Risposta API Wise non valida: ${response.status}`);
        }
        
        return res.json({
          success: true,
          message: 'Configurazione Wise valida'
        });
      } catch (wiseError: any) {
        return res.status(400).json({
          success: false,
          message: `Errore configurazione Wise: ${wiseError.message}`
        });
      }
    } 
    else if (id === 'bank') {
      // Per il bonifico bancario, verifichiamo che i dati essenziali siano presenti
      if (!config.iban || !config.accountName) {
        return res.status(400).json({
          success: false,
          message: 'Dati bancari incompleti (IBAN e intestatario obbligatori)'
        });
      }
      
      return res.json({
        success: true,
        message: 'Configurazione bonifico bancario valida'
      });
    } 
    else {
      return res.status(400).json({
        success: false,
        message: `Metodo di pagamento non supportato: ${id}`
      });
    }
  } catch (error) {
    console.error(`Errore durante il test del metodo di pagamento ${req.params.id}:`, error);
    return res.status(500).json({
      success: false,
      message: 'Errore interno del server: ' + (error instanceof Error ? error.message : String(error))
    });
  }
});

/**
 * Auto-configura Wise recuperando Profile ID e Account ID dall'API
 * POST /api/payments/payment-admin/wise/auto-configure
 * Accesso: payment admin
 */
router.post('/payment-admin/wise/auto-configure', isPaymentAdmin, async (req, res) => {
  try {
    console.log('🔍 Body ricevuto per auto-configure:', JSON.stringify(req.body));
    
    // Recupera i metodi di pagamento attuali
    const paymentMethods = await storage.getPaymentMethods();
    const wiseMethod = paymentMethods.find(m => m.id === 'wise');
    
    // Prendi l'API Key dal body della richiesta (frontend) o dal file salvato
    const apiKey = req.body.apiKey || wiseMethod?.config.apiKey;
    
    console.log('🔑 API Key dal body:', req.body.apiKey);
    console.log('🔑 API Key dal file:', wiseMethod?.config.apiKey);
    console.log('🔑 API Key finale scelta:', apiKey);
    
    if (!apiKey) {
      return res.status(400).json({
        success: false,
        message: 'API Key Wise non configurata. Inserisci prima l\'API Key.'
      });
    }
    
    // Se l'API Key arriva dal frontend, aggiornala anche nel wiseMethod
    if (req.body.apiKey && wiseMethod) {
      wiseMethod.config.apiKey = req.body.apiKey;
    }
    
    const baseUrl = 'https://api.transferwise.com';
    
    try {
      // Step 1: Recupera Profile ID usando v2 endpoint (compatibile con Personal account)
      console.log('🔍 Recupero Profile ID da Wise (v2 endpoint per account Personal)...');
      const profilesResponse = await fetch(`${baseUrl}/v2/profiles`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (!profilesResponse.ok) {
        const errorText = await profilesResponse.text();
        throw new Error(`Errore API Wise (profiles): ${profilesResponse.status} ${profilesResponse.statusText} - ${errorText}`);
      }
      
      const profiles = await profilesResponse.json();
      
      if (!profiles || profiles.length === 0) {
        return res.status(400).json({
          success: false,
          message: 'Nessun profilo trovato per questa API Key. Verifica che l\'autenticazione a due fattori sia abilitata.'
        });
      }
      
      const profileId = profiles[0].id;
      const profileType = profiles[0].type || 'personal';
      console.log(`✅ Profile ID recuperato: ${profileId} (tipo: ${profileType})`);
      
      // Step 2: Recupera Balance/Account ID usando v4 endpoint
      console.log('🔍 Recupero Balance ID da Wise (v4 endpoint)...');
      const balancesResponse = await fetch(`${baseUrl}/v4/profiles/${profileId}/balances?types=STANDARD`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (!balancesResponse.ok) {
        const errorText = await balancesResponse.text();
        throw new Error(`Errore API Wise (balances): ${balancesResponse.status} ${balancesResponse.statusText} - ${errorText}`);
      }
      
      const balances = await balancesResponse.json();
      
      if (!balances || balances.length === 0) {
        return res.status(400).json({
          success: false,
          message: 'Nessun balance Wise trovato. Assicurati di avere almeno una valuta attiva nel tuo account.'
        });
      }
      
      const accountId = balances[0].id;
      console.log(`✅ Balance ID recuperato: ${accountId}`);
      
      // Step 3: Aggiorna la configurazione Wise nel database
      wiseMethod.config.profileId = profileId.toString();
      wiseMethod.config.accountId = accountId.toString();
      
      await storage.savePaymentMethods(paymentMethods);
      
      console.log('✅ Configurazione Wise aggiornata automaticamente');
      
      return res.json({
        success: true,
        message: `Configurazione Wise completata automaticamente (account ${profileType})`,
        data: {
          profileId: profileId.toString(),
          accountId: accountId.toString(),
          profileType: profileType
        }
      });
      
    } catch (apiError: any) {
      console.error('❌ Errore durante la chiamata API Wise:', apiError);
      return res.status(400).json({
        success: false,
        message: `Errore API Wise: ${apiError.message}`
      });
    }
    
  } catch (error) {
    console.error('❌ Errore durante l\'auto-configurazione Wise:', error);
    return res.status(500).json({
      success: false,
      message: 'Errore interno del server: ' + (error instanceof Error ? error.message : String(error))
    });
  }
});

/**
 * Ottiene i metodi di pagamento disponibili per l'utente
 * GET /api/payments/available-methods
 * Accesso: tutti (pubblico)
 */
router.get('/available-methods', async (req, res) => {
  try {
    const paymentMethods = await storage.getPaymentMethods();
    
    // Restituisce solo i metodi attivi con informazioni di base (senza credenziali)
    const availableMethods = paymentMethods
      .filter(method => method.enabled)
      .map(method => ({
        id: method.id,
        name: method.name,
        // Solo informazioni pubbliche specifiche per ogni metodo
        publicConfig: method.id === 'stripe' 
          ? { 
              publicKey: method.config.publicKey,
              statementDescriptor: method.config.statementDescriptor 
            }
          : method.id === 'paypal'
          ? { 
              mode: method.config.mode 
            }
          : method.id === 'bank'
          ? {
              accountName: method.config.accountName,
              bankName: method.config.bankName,
              iban: method.config.iban,
              swift: method.config.swift,
              recipient: method.config.recipient || method.config.accountName,
              instructions: method.config.instructions
            }
          : {}
      }));
    
    return res.json(availableMethods);
  } catch (error) {
    console.error('Errore durante il recupero dei metodi di pagamento disponibili:', error);
    return res.status(500).json({
      success: false,
      message: 'Errore interno del server: ' + (error instanceof Error ? error.message : String(error))
    });
  }
});

/**
 * Verifica quale metodo di pagamento utilizzare per un abbonamento
 * GET /api/payments/subscription/:id/payment-method
 * Accesso: admin, staff
 */
router.get('/subscription/:id/payment-method', isAdminOrStaff, async (req, res) => {
  try {
    const { id } = req.params;
    
    // Ottieni l'abbonamento
    const subscription = await storage.getSubscription(parseInt(id));
    
    if (!subscription) {
      return res.status(404).json({
        success: false,
        message: 'Abbonamento non trovato'
      });
    }
    
    // Restituisci informazioni sul metodo di pagamento
    return res.json({
      subscriptionId: subscription.id,
      paymentMethod: subscription.paymentMethod,
      // Altre informazioni utili sul pagamento
      status: subscription.status,
      currentPeriodEnd: subscription.currentPeriodEnd
    });
  } catch (error) {
    console.error('Errore durante la verifica del metodo di pagamento:', error);
    return res.status(500).json({
      success: false,
      message: 'Errore interno del server: ' + (error instanceof Error ? error.message : String(error))
    });
  }
});

export default router;